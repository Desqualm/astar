#include <iostream>
#include <fstream>
#include <math.h>
#include <vector>
#include <sstream>
#include <cstdlib>
using namespace std;

struct Pos;
struct Grid;
double f(Grid* grid);

vector<Grid*> openList, closeList;
string nazwap = "grid.txt";
int n = 20, ** G;

void generateMap() {
    // Uruchamianie map_generator.exe
    int result = system("map_generator.exe");

    if (result != 0) {
        cout << "Error running map_generator.exe" << endl;
        exit(1);
    }
}

struct Pos {
    int x;
    int y;

    bool equalsTo(Pos* pos) {
        return (x == pos->x && y == pos->y);
    }
} start = { 0, 19 }, goal = { 19, 0 };

struct Grid {
    Pos* pos;
    Grid* parent;
    double fVal;

    Grid(Pos* pos, Grid* parent) {
        this->pos = pos;
        this->parent = parent;
        this->fVal = f(this);
        //show();
    }

    void show() {
        char text[100];
        sprintf(text, "(%d; %d) fVal = %.2f", pos->x, n - 1 - pos->y, fVal);
        cout << text << endl;
    }
};

double g(Grid* grid) {
    int cost = 0;
    Grid* currGrid = grid;
    while (!currGrid->pos->equalsTo(&start)) {
        cost++;
        currGrid = currGrid->parent;
    }
    return cost;
}

double h(Pos* pos) {
    return sqrt(pow(pos->x - goal.x, 2) + pow(pos->y - goal.y, 2));
}

double f(Grid* grid) {
    return g(grid) + h(grid->pos);
}

enum class Direction {
    LEFT, RIGHT, UP, DOWN
};

void createGridArray() {
    G = new int* [n];
    for (int i = 0; i < n; i++) {
        G[i] = new int[n];
    }
}

void readGridArray() {
    // Uruchom map_generator.exe, aby wygenerowa� plik grid.txt
    generateMap();

    ifstream file("grid.txt");

    if (file.is_open()) {
        string line;
        for (int i = 0; i < n; i++) {
            getline(file, line);
            istringstream iss(line);
            for (int j = 0; j < n; j++) {
                if (!(iss >> G[i][j])) {
                    cout << "Error reading grid.txt at position (" << i << ", " << j << ")." << endl;
                    exit(1);
                }
            }
        }
        file.close();
    }
    else {
        cout << "File 'grid.txt' does not exist or cannot be opened." << endl;
        exit(1);
    }
}

void showGridArray() {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << " ";

            if (G[i][j] == 0) cout << '?';      //free space on the map
            if (G[i][j] == 3) cout << '.';      //path to move
            if (G[i][j] == 5) cout << '#';      //barrier
        }
        cout << endl;
    }
}

void deleteGridArray() {
    for (int i = 0; i < n; i++) {
        delete[] G[i];
    }
    delete[] G;
}

bool isPosCorrect(Pos* pos) {
    if (pos->x < 0) return false;
    if (pos->y < 0) return false;
    if (pos->x >= n) return false;
    if (pos->y >= n) return false;
    if (G[pos->y][pos->x] == 5) return false;
    if (pos->x == start.x && pos->y == start.y) return false;

    return true;
}

Pos* getNewPosByDirection(Pos* parentPos, Direction dir) {
    if (dir == Direction::LEFT) return new Pos{ parentPos->x - 1, parentPos->y };
    if (dir == Direction::RIGHT) return new Pos{ parentPos->x + 1, parentPos->y };
    if (dir == Direction::UP) return new Pos{ parentPos->x, parentPos->y - 1 };
    if (dir == Direction::DOWN) return new Pos{ parentPos->x, parentPos->y + 1 };
    return new Pos{ -1, -1 };
}

Grid* getNewGrid(Grid* parent, Direction dir) {
    Pos* newPos = getNewPosByDirection(parent->pos, dir);

    if (!isPosCorrect(newPos))
        return nullptr;
    return new Grid(newPos, parent);
}

Grid* getFromOpenListByPos(Pos* pos) {
    for (Grid* grid : openList) {
        if (grid->pos->equalsTo(pos)) {
            return grid;
        }
    }
    return nullptr;
}

bool openListContains(Grid* gridToCheck) {
    for (Grid* grid : openList) {
        if (grid->pos->equalsTo(gridToCheck->pos)) {
            return true;
        }
    }
    return false;
}

bool closeListContains(Grid* gridToCheck) {
    for (Grid* grid : closeList) {
        if (grid->pos->equalsTo(gridToCheck->pos)) {
            return true;
        }
    }
    return false;
}

void addGridToCloseList(Grid* currGrid) {
    closeList.push_back(currGrid);
}

void addNeighborGridsToOpenList(Grid* currGrid) {
    Grid* down = getNewGrid(currGrid, Direction::DOWN);
    Grid* left = getNewGrid(currGrid, Direction::LEFT);
    Grid* up = getNewGrid(currGrid, Direction::UP);
    Grid* right = getNewGrid(currGrid, Direction::RIGHT);

    if (down != nullptr && !openListContains(down)) openList.push_back(down);
    else if (down != nullptr && openListContains(down)) {
        Grid* downGrid = getFromOpenListByPos(down->pos);
        if (downGrid->fVal > down->fVal)
            downGrid->parent = currGrid;
    }

    if (left != nullptr && !openListContains(left)) openList.push_back(left);
    else if (left != nullptr && openListContains(left)) {
        Grid* leftGrid = getFromOpenListByPos(left->pos);
        if (leftGrid->fVal > left->fVal)
            leftGrid->parent = currGrid;
    }

    if (up != nullptr && !openListContains(up)) openList.push_back(up);
    else if (up != nullptr && openListContains(up)) {
        Grid* upGrid = getFromOpenListByPos(up->pos);
        if (upGrid->fVal > up->fVal)
            upGrid->parent = currGrid;
    }

    if (right != nullptr && !openListContains(right)) openList.push_back(right);
    else if (right != nullptr && openListContains(right)) {
        Grid* rightGrid = getFromOpenListByPos(right->pos);
        if (rightGrid->fVal > right->fVal)
            rightGrid->parent = currGrid;
    }
}

Grid* getLowestGridFromOpenList(Grid* currGrid) {
    Grid* lowestNeighborGrid = nullptr;;

    for (int i = openList.size() - 1; i >= 0; i--) {
        Grid* grid = openList[i];

        if (!closeListContains(grid)) {
            if (lowestNeighborGrid == nullptr) {
                lowestNeighborGrid = grid;
            }
            else if (grid->fVal < lowestNeighborGrid->fVal) {
                lowestNeighborGrid = grid;
            }
        }
    }
    return lowestNeighborGrid;
}

void showList(vector<Grid*> list) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            Grid* grid = getFromOpenListByPos(new Pos{ j, i });

            if (grid != nullptr) {
                char text[100];
                sprintf(text, "%2.2f ", grid->fVal);
                cout << text;
            }
            else {
                cout << "|XX| ";
            }
        }
        cout << endl;
    }
}

void showResult(Grid* grid) {
    cout << "Result from goal to start:" << endl;
    Grid* currGrid = grid;
    currGrid->show();
    G[currGrid->pos->y][currGrid->pos->x] = 3;
    do {
        currGrid = currGrid->parent;
        G[currGrid->pos->y][currGrid->pos->x] = 3;
        currGrid->show();
    } while (!currGrid->pos->equalsTo(&start));
}

void doAstar() {
    Grid* currGrid = new Grid(&start, nullptr);

    do {
        addGridToCloseList(currGrid);
        addNeighborGridsToOpenList(currGrid);
        currGrid = getLowestGridFromOpenList(currGrid);

        //showList(openList);
        //cout << "Lowest grid: ";
        //currGrid->show();
    } while (!currGrid->pos->equalsTo(&goal));

    showResult(currGrid);
}

int main(void) {
    createGridArray();
    readGridArray();
    doAstar();
    showGridArray();
    deleteGridArray();
    return 0;
}
